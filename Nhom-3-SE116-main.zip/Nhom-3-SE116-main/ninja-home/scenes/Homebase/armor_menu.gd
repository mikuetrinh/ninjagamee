extends Control

@onready var current_leather_label = $"Current leather" 
@onready var cost_label = $"Cost per upgrade"
@onready var close_btn = $close_button

@onready var slot_input_ui = $InputSlot
@onready var slot_output_ui = $OutputSlot

var upgrade_inv: InvData

var player_leather: int:
	get: 
		return InventoryManager.count_item_by_name("Leather")

func _ready():
	visible = false
	close_btn.pressed.connect(_on_close_button_pressed)
	
	upgrade_inv = InvData.new()
	upgrade_inv.items = [InvSlot.new(), InvSlot.new()]
	
	slot_input_ui.slot_pos = 0
	slot_output_ui.slot_pos = 1
	
	slot_input_ui.slot_clicked.connect(_on_input_slot_clicked)
	slot_output_ui.slot_clicked.connect(_on_output_slot_clicked)
	
	GameEvents.InventoryChange.connect(update_ui)

func open_menu():
	print("called to open")
	visible = true
	update_ui()

func put_item_into_input(item_slot: InvSlot):
	if item_slot == null or item_slot.data == null:
		clear_upgrade_slots()
		return
		
	upgrade_inv.items[0].data = item_slot.data
	upgrade_inv.items[0].amount = 1
	
	update_ui()

func clear_upgrade_slots():
	upgrade_inv.items[0].data = null
	upgrade_inv.items[0].amount = 0
	upgrade_inv.items[1].data = null
	upgrade_inv.items[1].amount = 0
	update_ui()

func update_ui():
	var input_item = upgrade_inv.items[0].data
	
	if input_item != null and input_item.is_upgradable and input_item.upgrade_result != null:
		var cost = input_item.leather_cost
		cost_label.text = "Cost: " + str(cost) + " Leather"
		
		if player_leather >= cost:
			upgrade_inv.items[1].data = input_item.upgrade_result
			upgrade_inv.items[1].amount = 1
		else:
			upgrade_inv.items[1].data = null
			upgrade_inv.items[1].amount = 0
	else:
		cost_label.text = "Cost: -- Leather"
		upgrade_inv.items[1].data = null
		upgrade_inv.items[1].amount = 0
		
	slot_input_ui.update_item(upgrade_inv.items[0])
	slot_output_ui.update_item(upgrade_inv.items[1])
	
	current_leather_label.text = "Current Leather: " + str(player_leather)

func _on_output_slot_clicked(index: int, item_slot: InvSlot):
	var output_item = upgrade_inv.items[1].data
	var input_item = upgrade_inv.items[0].data
	
	if input_item == null or output_item == null:
		return
		
	var cost = input_item.leather_cost
	
	if InventoryManager.remove_item_by_name("Leather", cost):
		print("Nâng cấp thành công! Đã trừ nguyên liệu.")
		
		InventoryManager.add_item(output_item, 1)
		
		upgrade_inv.items[0].data = null
		upgrade_inv.items[0].amount = 0
		
		update_ui()
	else:
		print("Không đủ Leather!")

func _on_input_slot_clicked(index: int, item_slot: InvSlot):
	if upgrade_inv.items[0].data != null:
		InventoryManager.add_item(upgrade_inv.items[0].data, 1)
		clear_upgrade_slots()

func _on_close_button_pressed():
	if upgrade_inv.items[0].data != null:
		InventoryManager.add_item(upgrade_inv.items[0].data, 1)
		clear_upgrade_slots()
	
	GameEvents.CloseAllMenu.emit()
