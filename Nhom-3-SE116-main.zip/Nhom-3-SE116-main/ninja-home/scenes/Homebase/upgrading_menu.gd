extends Node2D

@onready var current_coins_label = $"Current coins"
@onready var damage_label = $Damage
@onready var level_label = $"Weapon's level"
@onready var cost_label = $"Cost per upgrade"
@onready var upgrade_btn = $upgrade_button
@onready var close_btn = $close_button

var player_coins = 1000
var weapon_damage = 50
var weapon_level = 1

func _ready():
	upgrade_btn.pressed.connect(_on_upgrade_button_pressed)
	close_btn.pressed.connect(_on_close_button_pressed)
	update_ui()
	
func open_menu():
	visible = true
	update_ui()
	
func update_ui():
	var cost = get_upgrade_cost()
	current_coins_label.text = "Current Coins: " + str(player_coins)
	damage_label.text = "Damage: " + str(weapon_damage)
	level_label.text = "Level: " + str(weapon_level)
	cost_label.text = "Cost per Upgrade: " + str(cost)
	
	if player_coins >= cost:
		upgrade_btn.disabled = false
	else:
		upgrade_btn.disabled = true

func get_upgrade_cost() -> int:
	return weapon_level * 150

func _on_upgrade_button_pressed():
	var cost = get_upgrade_cost()
	if player_coins >= cost:
		player_coins -= cost
		weapon_level += 1
		weapon_damage += 15
		update_ui()

func _on_close_button_pressed():
	hide()
