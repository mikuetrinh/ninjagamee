extends Control

@onready var close_btn = $close_button

@export var shop_slots_ui: Array[Control] = [] 

@export var shop_inv: InvData 

var original_items_backup: Array[Resource] = []


func _ready():
	visible = false
	close_btn.pressed.connect(_on_close_button_pressed)
	
	if shop_inv == null:
		shop_inv = InvData.new()
		shop_inv.items = [InvSlot.new(), InvSlot.new(), InvSlot.new()]
	
	original_items_backup.resize(shop_inv.items.size())
	for i in range(shop_inv.items.size()):
		if shop_inv.items[i] and shop_inv.items[i].data:
			original_items_backup[i] = shop_inv.items[i].data
	
	if shop_slots_ui.is_empty():
		shop_slots_ui = [$Slot1, $Slot2, $Slot3]
	
	for i in range(shop_slots_ui.size()):
		if shop_slots_ui[i]:
			shop_slots_ui[i].slot_pos = i
			shop_slots_ui[i].slot_clicked.connect(_on_shop_slot_clicked)
	
	update_ui()
	GameEvents.InventoryChange.connect(update_ui)


func open_menu():
	visible = true
	update_ui()

func restock_slot(slot_index: int):
	if slot_index >= shop_inv.items.size():
		return
		
	var original_item = original_items_backup[slot_index]
	
	if original_item != null:
		shop_inv.items[slot_index].data = original_item
		shop_inv.items[slot_index].amount = 1
	else:
		shop_inv.items[slot_index].data = null
		shop_inv.items[slot_index].amount = 0


func update_ui():
	for i in range(min(shop_inv.items.size(), shop_slots_ui.size())):
		var slot_node = shop_slots_ui[i]
		if slot_node:
			slot_node.update_item(shop_inv.items[i])
			
			var item_data = shop_inv.items[i].data
			
			var price_label = slot_node.get_node_or_null("Label") if slot_node.has_node("Label") else slot_node.get_node_or_null("PriceLabel")
			
			if price_label:
				if item_data:
					var cost = item_data.purchase_cost if "purchase_cost" in item_data else 0
					price_label.text = str(cost)
				else:
					price_label.text = "Sold Out"


func _on_shop_slot_clicked(index: int, item_slot: InvSlot):
	var shop_slot = shop_inv.items[index]
	if shop_slot == null or shop_slot.data == null:
		return
		
	var item_to_buy = shop_slot.data
	
	var cost = item_to_buy.purchase_cost if "purchase_cost" in item_to_buy else 0
	
	if InventoryManager.get_coins() >= cost:
		InventoryManager.change_coins(-cost)
		print("Mua thành công: ", item_to_buy.item_name if "item_name" in item_to_buy else item_to_buy.name)
		
		InventoryManager.add_item(item_to_buy, 1)
		
		restock_slot(index)
		update_ui()
	else:
		print("Không đủ tiền! Bạn cần: ", cost, " Coins.")


func _on_close_button_pressed():
	GameEvents.CloseAllMenu.emit()
	visible = false
