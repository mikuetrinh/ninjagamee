extends Node2D

@onready var interaction_area = $InteractionArea

@export var armor_menu_scene: PackedScene 

var is_player_nearby: bool = false

func _ready():
	interaction_area.input_event.connect(_on_InteractionArea_input_event)
	interaction_area.body_entered.connect(func(body): if body.name == "Player": is_player_nearby = true)
	interaction_area.body_exited.connect(func(body): if body.name == "Player": is_player_nearby = false)

func _on_InteractionArea_input_event(_viewport, event, _shape_idx):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		trigger_interaction()

func _unhandled_input(event):
	if is_player_nearby and event.is_action_pressed("interact"):
		trigger_interaction()
		get_viewport().set_input_as_handled()

func trigger_interaction():
	if armor_menu_scene:
		GameEvents.InteractMenu.emit(armor_menu_scene)
