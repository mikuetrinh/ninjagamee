extends CanvasLayer

@onready var background: NinePatchRect = $NinePatchRect
@onready var respawn_btn: Button = $NinePatchRect/HBoxContainer/Button
@onready var exit_btn: Button = $NinePatchRect/HBoxContainer/Button2

var target_spawn_position: Vector2 = Vector2(100, 0) 

func _ready() -> void:
	visible = false
	background.modulate.a = 0.0
	
	respawn_btn.pressed.connect(_on_respawn_pressed)
	exit_btn.pressed.connect(_on_exit_pressed)
	
	GameEvents.player_died.connect(_on_player_real_death)

func _on_player_real_death(data: DamageData):
	show_screen()

func show_screen() -> void:
	visible = true
	get_tree().paused = true
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	var tween = create_tween()
	tween.tween_property(background, "modulate:a", 1.0, 0.5).set_trans(Tween.TRANS_SINE)

func _on_respawn_pressed() -> void:
	get_tree().paused = false
	visible = false
	background.modulate.a = 0.0
	SceneManager.change_scene(WorldManager.target_scene, WorldManager.spawn_pos, null)

func _on_exit_pressed() -> void:
	get_tree().quit()
