extends Label

func update_hp(cur_hp: float, max_hp: float):
	text = str(cur_hp)
