extends Area2D

@export var damage: float = 0.0

var scan_timer: float = 0.0
const SCAN_INTERVAL: float = 0.05

func _ready() -> void:
	area_entered.connect(_on_area_entered)
	
	set_physics_process(false)

func _on_area_entered(area: Area2D) -> void:
	if area is HitCheck:
		if not is_physics_processing():
			scan_timer = SCAN_INTERVAL
			set_physics_process(true)

func _physics_process(delta: float) -> void:
	scan_timer += delta
	
	if scan_timer >= SCAN_INTERVAL:
		scan_timer -= SCAN_INTERVAL
		
		var overlapping_areas = get_overlapping_areas()
		var targets_found := false
		
		for area in overlapping_areas:
			if area is HitCheck:
				targets_found = true
				var combat_packet = DamageData.new(self, global_position)
				
				combat_packet.add_damage(damage, "Physical")
				area.handle_hit(combat_packet)
		
		if not targets_found:
			set_physics_process(false)
