extends Area2D

@export_file("*.tscn") var target_scene: String

@export var spawn_pos: Vector2

func _ready():
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: BaseCharacter):
	if body.is_in_group("Player") and body is BaseCharacter:
			print("Player Entered Portal")
			if target_scene != "":
				SceneManager.change_scene(target_scene, spawn_pos, body)
		
