extends Node2D

var bgm: AudioStream = preload("res://assets/sounds/tap 1.mp3")
func _ready() -> void:
	SoundManager.play_bgm(bgm)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
