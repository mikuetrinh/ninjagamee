extends Node

var inv: InvData:
	set(value):
		inv = value
		GameEvents.InventoryChange.emit()
var hotbar_selected_item : InvSlot = null
signal AmountUpdate
var is_full: bool

func _ready():
	GameEvents.InventoryChange.emit()

func get_selected_item():
	return hotbar_selected_item
	
func set_selected_item(item: InvSlot):
	hotbar_selected_item = item
	if item == null:
		return
		
func count_item_by_name(target_name: String) -> int:
	var count: int = 0
	for slot in inv.items:
		if slot == null or slot.data == null or slot.amount == 0: 
			continue
		if slot.data.item_name == target_name: 
			count += slot.amount
	return count


func remove_item_by_name(target_name: String, amount_to_remove: int) -> bool:
	if count_item_by_name(target_name) < amount_to_remove:
		return false
		
	for slot in inv.items:
		if slot == null or slot.data == null or slot.amount == 0:
			continue
			
		if slot.data.item_name == target_name:
			if slot.amount >= amount_to_remove:
				slot.amount -= amount_to_remove
				amount_to_remove = 0
			else:
				amount_to_remove -= slot.amount
				slot.amount = 0
				
			if slot.amount == 0:
				slot.data = null
				
		if amount_to_remove <= 0:
			break
			
	GameEvents.InventoryChange.emit()
	return true
	
func add_item(new_item: InvItemData, amount: int) -> bool:
	if new_item.type == "Coin":
		inv.coins += amount
		GameEvents.InventoryChange.emit()
		return true
	else:
		for item in inv.items:
			if item == null:
				continue
			if item.data and item.data.resource_path == new_item.resource_path and item.amount < item.data.max_stack:
				var space = item.data.max_stack - item.amount
				var to_add = min(space, amount)

				item.amount += to_add
				amount -= to_add

				if amount <= 0:
					GameEvents.InventoryChange.emit()
					return true
					
		for item in inv.items:
			if item == null:
				continue
			if item.data == null:
				var to_add = min(new_item.max_stack, amount)
				item.data = new_item
				item.amount = to_add
				amount -= to_add

				if amount <= 0:
					GameEvents.InventoryChange.emit()
					return true
	GameEvents.InventoryChange.emit()
	return false
	
func get_coins() -> int:
	return inv.coins
	
func change_coins(am: int):
	if inv.coins + am < 0:
		return
		
	inv.coins += am
	GameEvents.InventoryChange.emit()
	
func swap_slots_by_reference(from_slot: InvSlot, to_slot: InvSlot):
	var temp_data = from_slot.data
	var temp_amount = from_slot.amount
	from_slot.data = to_slot.data
	from_slot.amount = to_slot.amount
	to_slot.data = temp_data
	to_slot.amount = temp_amount

	GameEvents.InventoryChange.emit()
