extends Resource

class_name InvData
@export var items: Array[InvSlot]
@export var armor: Array[InvSlot] = [null, null, null]
@export var coins: int = 0
var effects: Dictionary = {}

func setup():
	if not GameEvents.EmptySlot.is_connected(delete_item):
		GameEvents.EmptySlot.connect(delete_item)
		
	for i in range(items.size()):
		if items[i] == null:
			items[i] = InvSlot.new()
		items[i].location = i
		
	for i in range(armor.size()):
		if armor[i] == null:
			armor[i] = InvSlot.new()
		
	InventoryManager.set_selected_item(items[0])
	
func delete_item(idx: int):
	print("deleting")
	items[idx].data = null
	items[idx].amount = 0
	GameEvents.InventoryChange.emit()
