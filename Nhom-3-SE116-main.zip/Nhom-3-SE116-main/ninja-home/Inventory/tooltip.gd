extends Control
@onready var background: NinePatchRect = $Background
@onready var slot_name: Label = $Background/Name
@onready var type: Label = $Background/Type
@onready var eff: RichTextLabel = $Background/VBoxContainer/Effect
@onready var desc: Label = $Background/VBoxContainer/Desc

const OFFSET = Vector2(12, 12)

func _ready():
	GameEvents.ShowTooltip.connect(display_tooltip)
	GameEvents.ShowEffectTooltip.connect(display_effect_tooltip)
	GameEvents.HideTooltip.connect(hide_tooltip)
	hide()
	set_process(false) 

func _process(_delta):
	var mouse_pos = get_global_mouse_position()
	var viewport_size = get_viewport_rect().size
	
	var tooltip_size = background.size
	
	var target_pos = mouse_pos + OFFSET

	if target_pos.x + tooltip_size.x > viewport_size.x:
		target_pos.x = mouse_pos.x - tooltip_size.x - OFFSET.x

	if target_pos.y + tooltip_size.y > viewport_size.y:
		target_pos.y = mouse_pos.y - tooltip_size.y - OFFSET.y

	target_pos.x = clampf(target_pos.x, 0.0, viewport_size.x - tooltip_size.x)
	target_pos.y = clampf(target_pos.y, 0.0, viewport_size.y - tooltip_size.y)

	position = target_pos
	
	global_position = target_pos

func display_tooltip(data: InvSlot):
	slot_name.text = data.data.item_name + " x " + str(data.amount)
	type.text = data.data.type
	eff.text = data.data.effect_description
	desc.text = data.data.desc
	
	global_position = get_global_mouse_position() + OFFSET
	
	show()
	set_process(true)
	
func display_effect_tooltip(effect_name: String, time_left_str: String, effect_bbcode: String):
	slot_name.text = effect_name
	type.text = time_left_str
	eff.text = effect_bbcode
	desc.text = ""
	
	global_position = get_global_mouse_position() + OFFSET
	
	show()
	set_process(true)
	
func hide_tooltip():
	hide()
	set_process(false)
