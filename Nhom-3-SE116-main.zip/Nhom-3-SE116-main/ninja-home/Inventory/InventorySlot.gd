extends Resource

class_name InvSlot
@export var data : InvItemData
@export var amount : int = 1
var location : int

var active_effect_ids: Array[String] = []
