extends Control

var is_open = true
signal item_selected
@export var slot_ui_scene: PackedScene = preload("res://Inventory/inv_ui_slot.tscn")
@onready var slots: Array = $HotbarBackground/GridContainer.get_children().slice(0, 5)
var selected_idx := 0

func _ready():
	if InventoryManager.has_signal("inventory_changed"):
		InventoryManager.inventory_changed.connect(update_slots)
	GameEvents.InventoryChange.connect(update_slots)
	
	for i in range(slots.size()):
		slots[i].slot_pos = i
		if not slots[i].slot_clicked.is_connected(sel_slot):
			slots[i].slot_clicked.connect(sel_slot)
			
	update_slots()
	if slots.size() > 0 and selected_idx < slots.size():
		slots[selected_idx].on_selected()


func sel_slot(index: int, item: InvSlot):
	if selected_idx < slots.size():
		slots[selected_idx].off_selected()
	selected_idx = index
	
	if selected_idx < slots.size():
		slots[selected_idx].on_selected()
	InventoryManager.set_selected_item(item)
	item_selected.emit(get_sel_item())
	
func _process(_delta):
	pass

func get_sel_item() -> InvSlot:
	var inv = InventoryManager.inv
	if not inv: return null
	
	if selected_idx < 0 or selected_idx >= inv.items.size(): 
		return null
	return inv.items[selected_idx]
	
func update_slots():
	var inv = InventoryManager.inv
	if not inv: return
	
	for i in range(slots.size()):
		if i < inv.items.size():
			slots[i].visible = true
			slots[i].update_item(inv.items[i])
		else:
			slots[i].visible = false
