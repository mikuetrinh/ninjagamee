extends Resource

class_name InvItemData
@export var item_name : String = ""
@export var type : String = ""
@export var desc : String = ""
@export var texture : Texture2D
@export var placable : bool = false
@export var autotile : bool = false
@export var is_tool : bool = false
@export var is_weapon : bool = false
@export var is_armor : bool = false
@export var is_food : bool = false
@export var max_stack : int = 99
@export var is_upgradable : bool = false
@export var purchase_cost: int = 10

@export_group("Upgrade")
@export var upgrade_result: InvItemData = null
@export var leather_cost: int = 0

@export_group("Animation")
@export var is_animated: bool = false
@export var sprite_frames: SpriteFrames

@export_group("Tile properties")
@export var source_id: int
@export var coords: Vector2i = Vector2i.ZERO

@export_group("Item Effects")
@export var item_effects: Array[StatusEffect] = []

var effect_description: String:
	get:
		if item_effects.size() == 0:
			return ""
		var descriptions: Array[String] = []
		for effect in item_effects:
			if effect:
				var final_params = _get_final_params_for(effect)
				descriptions.append(effect.get_effect_string(final_params))
		return "\n".join(descriptions)

func _get_final_params_for(effect: StatusEffect) -> Dictionary:
	return {
		"intensity": effect.intensity,
		"density": effect.density,
		"duration": effect.duration
	}
