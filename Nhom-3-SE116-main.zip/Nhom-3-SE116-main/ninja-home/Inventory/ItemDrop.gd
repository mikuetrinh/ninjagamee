extends CharacterBody2D

@export var item_data: InvItemData
@export var amount: int = 1
@onready var sprite: Sprite2D = $Sprite2D
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
var coin_sfx: AudioStream = preload("res://assets/sounds/SampleSounds/coin.mp3")
var item_sfx: AudioStream = preload("res://assets/sounds/sfx/BUBBLE POP SOUND EFFECT - FREE - Part.mp3")

const BOUNCE_THRESHOLD_X := 20.0
const BOUNCE_THRESHOLD_Y := 50.0
const BOUNCE_EFFICIENCY := 0.5

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _ready():
	if item_data:
		sprite.texture = item_data.texture
	
	$PickArea.body_entered.connect(_on_body_entered)
	setup_visual()

func setup_visual():
	if not item_data:
		return
	if "is_animated" in item_data and item_data.is_animated and item_data.sprite_frames:
		sprite.visible = false 
		
		animated_sprite.visible = true
		animated_sprite.sprite_frames = item_data.sprite_frames
		animated_sprite.play("Idle")
	else:
		animated_sprite.visible = false
		
		sprite.visible = true
		if item_data.texture:
			sprite.texture = item_data.texture
	
func _physics_process(delta):
	if not is_on_floor():
		velocity.y += gravity * delta
		
	var old_velocity := velocity
	
	move_and_slide()
	
	if is_on_floor():
		if abs(old_velocity.y) > BOUNCE_THRESHOLD_Y:
			velocity.y = -old_velocity.y * BOUNCE_EFFICIENCY
			velocity.x = old_velocity.x * BOUNCE_EFFICIENCY
		else:
			velocity.y = 0.0
			velocity.x = move_toward(velocity.x, 0.0, 400.0 * delta)

	if is_on_wall():
		if abs(old_velocity.x) > BOUNCE_THRESHOLD_X:
			velocity.x = -old_velocity.x * BOUNCE_EFFICIENCY
		else:
			velocity.x = 0.0

func _on_body_entered(body):
	if body is Player:
		var success: bool = InventoryManager.add_item(item_data, 1)
		if item_data.type == "Coin":
			SoundManager.play_sfx(coin_sfx)
		else:
			SoundManager.play_sfx(item_sfx)
		print("collected")
		if success:
			queue_free()
