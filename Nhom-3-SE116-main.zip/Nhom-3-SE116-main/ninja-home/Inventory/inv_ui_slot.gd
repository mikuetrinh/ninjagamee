extends Panel

class_name InvSlotUI
@onready var item_visual: Sprite2D = $CenterContainer/Panel/Display
@onready var shadow: Sprite2D = $CenterContainer/Panel/Shadow
@onready var count_label: Label = $CenterContainer/Panel/Label
@onready var selection_border: Sprite2D = $SelBorder
var slot_item: InvSlot
var slot_pos: int
@export var allowed_type: String = "Any"
var allowed_specific: Array[InvSlot]
@export var allowed_dragging_into: bool = true
@export var allowed_dragging_out: bool = true
signal slot_clicked(index: int, item: InvSlot)
signal dragged_out

const SHADOW = {
	"helmet": preload("res://assets/inventory/Helmet_Silhouette.png"),
	"chestplate": preload("res://assets/inventory/Chestplate_Silhouette.png"),
	"boots": preload("res://assets/inventory/Boots_Silhouette.png")
}

var selected := false

func _ready():
	selection_border.visible = false
	if allowed_type != "Any":
		shadow.texture = SHADOW[allowed_type.to_lower()]
	mouse_entered.connect(on_mouse_entered)
	mouse_exited.connect(on_mouse_exited)
	
func on_mouse_entered():
	if slot_item and slot_item.data and not Input.is_action_pressed("primary"):
		GameEvents.ShowTooltip.emit(slot_item)
		
func on_mouse_exited():
	GameEvents.HideTooltip.emit()
	
func update_item(item: InvSlot):
	slot_item = item
	count_label.visible = false
	if item == null or item.data == null or item.amount == 0:
		item_visual.visible = false
	else:
		item_visual.visible = true
		item_visual.texture = item.data.texture
		if item.amount > 1:
			count_label.visible = true
			count_label.text = str(item.amount)
		
		
func on_selected():
	selected = true
	selection_border.visible = true
	
func off_selected():
	selected = false
	selection_border.visible = false
	
func _get_drag_data(_at_position: Vector2) -> Variant:
	if not allowed_dragging_out:
		return null
	if slot_item == null or slot_item.data == null or slot_item.amount < 1:
		return null

	var preview_texture = TextureRect.new()
	preview_texture.texture = slot_item.data.texture
	preview_texture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview_texture.custom_minimum_size = Vector2(40, 40)
	item_visual.visible = false
	
	preview_texture.position = -preview_texture.custom_minimum_size / 2
	
	var preview_control = Control.new()
	preview_control.top_level = true
	preview_control.add_child(preview_texture)
	dragged_out.emit()
	
	set_drag_preview(preview_control)
	
	return { "source_slot": slot_item, "source_ui": self }


func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	if not allowed_dragging_into:
		return false
	if not (data is Dictionary and data.has("source_slot") and data["source_slot"] is InvSlot):
		return false
		
	var incoming_slot = data["source_slot"] as InvSlot
	
	if incoming_slot == null or incoming_slot.data == null:
		return false
	
	if allowed_type != "Any":
		if incoming_slot.data and incoming_slot.data.type != allowed_type:
			return false
			
	if data.has("source_ui") and data["source_ui"].allowed_type != "Any":
		if slot_item and slot_item.data:
			if slot_item.data.type != data["source_ui"].allowed_type:
				return false
				
	return true

func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var from_slot = data["source_slot"] as InvSlot
	var to_slot = slot_item
	
	if from_slot == to_slot:
		return
		
	print(from_slot)
	InventoryManager.swap_slots_by_reference(from_slot, to_slot)
	slot_clicked.emit(to_slot.location, to_slot.data)
	
func _notification(what: int) -> void:
	if what == NOTIFICATION_DRAG_END:
		if slot_item and slot_item.data and slot_item.amount > 0:
			item_visual.visible = true
		else:
			item_visual.visible = false
			
		GameEvents.InventoryChange.emit()
		
func _gui_input(event: InputEvent):
	if event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			if slot_item: slot_clicked.emit(slot_pos, slot_item)
			else: slot_clicked.emit(slot_pos, null)
			
			accept_event()
			
