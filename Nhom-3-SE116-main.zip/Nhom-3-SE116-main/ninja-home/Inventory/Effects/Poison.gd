class_name PoisonEffect
extends StatusEffect

func _init():
	effect_id = "Poison"

func apply(character: BaseCharacter, final_params: Dictionary, stats_manager: StatsManager) -> void:
	if final_params.has("duration"): duration = final_params["duration"]
	if final_params.has("intensity"): intensity = final_params["intensity"]
	if final_params.has("density"): density = final_params["density"]

func on_tick(character: BaseCharacter, final_params: Dictionary = {}):
	var dmg_per_tick = final_params.get("intensity", self.intensity)
	var poison_packet: DamageData = DamageData.new(null, character.global_position)
	poison_packet.add_damage(dmg_per_tick, "True")
	character.take_damage(poison_packet)
		
func tooltip_style(raw_text: String) -> String:
	var styled_text = raw_text
	styled_text = "[color=#" + text_color.to_html(false) + "]" + styled_text + "[/color]"
	styled_text = "[font_size=" + str(font_size) + "]" + styled_text + "[/font_size]"
	if outline_size > 0:
		styled_text = "[outline_size=" + str(outline_size) + "][outline_color=#" + outline_color.to_html(false) + "]" + styled_text + "[/outline_color][/outline_size]"
	if font_file:
		styled_text = "[font=" + font_file.resource_path + "]" + styled_text + "[/font]"
		
	return styled_text
		
func get_effect_string(final_params: Dictionary = {}) -> String:
	var result := ""
	if icon:
		result += "[img=24x24]" + icon.resource_path + "[/img] "
	
	var final_intensity = final_params.get("intensity", self.intensity)
	var final_density = final_params.get("density", self.density)
	var final_duration = final_params.get("duration", self.duration)
	
	var content = "Poison -" + str(final_intensity) + " HP"
	if final_density != 1.0:
		content += "/" + str(final_density) + "s "
	else:
		content += "/s "
	if final_duration > 0:
		var duration_str = "%.1fs" % final_duration
		content += "for " + duration_str
	else:
		content += "permanently"
		
	result += tooltip_style(content)
	return result
