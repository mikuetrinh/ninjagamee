extends Node

var effects := {}

func _ready() -> void:
	_register(preload("res://Inventory/Effects/Resource/Regen.tres"))
	_register(preload("res://Inventory/Effects/Resource/SpeedUpAdd.tres"))

func _register(effect: StatusEffect) -> void:
	if effect:
		if effect.effect_id == "":
			push_error("Effect chưa được đặt tên trong Resource Inspector: " + effect.resource_path)
			return
		effects[effect.effect_id] = effect

func get_effect(effect_name: String) -> StatusEffect:
	return effects.get(effect_name)

func apply_effect(target: Node, effect_source: Variant, custom_params: Dictionary = {}) -> void:
	if not is_instance_valid(target) or not target.has_node("StatsManager"):
		push_warning("Mục tiêu không hợp lệ hoặc không có StatsManager để nhận hiệu ứng")
		return
		
	var stats_manager = target.get_node("StatsManager")
	
	if effect_source is Array:
		for source in effect_source:
			apply_effect(target, source, custom_params)
		return
		
	var final_effect: StatusEffect = null
	
	if effect_source is String:
		final_effect = get_effect(effect_source)
		
	elif effect_source is StatusEffect:
		final_effect = effect_source.duplicate()
		
	if final_effect:
		stats_manager.add_effect(final_effect, custom_params)
