class_name SlowdownAddEffect
extends StatusEffect

func _init():
	effect_id = "SlowdownAdd"
	
func apply(character: BaseCharacter, final_params: Dictionary, stats_manager: StatsManager) -> void:
	var amt = final_params.get("intensity", self.intensity)
	
	stats_manager.speed_add -= amt 

func on_expire(character: BaseCharacter, final_params: Dictionary, stats_manager: StatsManager) -> void:
	var amt = final_params.get("intensity", self.intensity)
	
	stats_manager.speed_add += amt
		
func tooltip_style(raw_text: String) -> String:
	var styled_text = raw_text
	styled_text = "[color=#" + text_color.to_html(false) + "]" + styled_text + "[/color]"
	styled_text = "[font_size=" + str(font_size) + "]" + styled_text + "[/font_size]"
	if outline_size > 0:
		styled_text = "[outline_size=" + str(outline_size) + "][outline_color=#" + outline_color.to_html(false) + "]" + styled_text + "[/outline_color][/outline_size]"
	if font_file:
		styled_text = "[font=" + font_file.resource_path + "]" + styled_text + "[/font]"
		
	return styled_text
		
func get_effect_string(final_params: Dictionary = {}) -> String:
	var result := ""
	if icon:
		result += "[img=24x24]" + icon.resource_path + "[/img] "
	
	var content = " -" + str(intensity) + " Movement Speed"
		
	result += tooltip_style(content)
	return result
