class_name StatusEffect
extends Resource

var effect_id: String = ""
@export var icon: Texture2D
@export var duration: float = 0.0
@export var intensity: float = 1.0
@export var density: float = 1.0 #how long between each application

@export_group("Tooltip Style")
var font_file: Font = preload("res://assets/fonts/UTM Neo Sans Intel.ttf")
@export var font_size: int = 18
@export var text_color: Color = Color.WHITE
@export var outline_size: int = 0
@export var outline_color: Color = Color.BLACK

func apply(character: BaseCharacter, final_params: Dictionary, stats_manager: StatsManager):
	pass

func on_tick(character: BaseCharacter, final_params: Dictionary = {}):
	pass
	
func on_expire(character: BaseCharacter, final_params: Dictionary, stats_manager: StatsManager):
	pass
	
func get_effect_string(final_params: Dictionary = {}) -> String:
	return "None"
	
func tooltip_style(raw_text: String) -> String:
	return ""
	
