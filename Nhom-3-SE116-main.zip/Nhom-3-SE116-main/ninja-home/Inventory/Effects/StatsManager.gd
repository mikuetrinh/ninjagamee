class_name StatsManager
extends Node

signal stats_updated
var character: BaseCharacter

class ActiveEffect:
	var data: StatusEffect
	var time_left: float
	var tick_timer: float
	var instance_id: String 

	func _init(effect_data: StatusEffect, custom_params: Dictionary, target_char: BaseCharacter):
		self.data = effect_data
		self.instance_id = effect_data.effect_id + "_" + str(effect_data.get_instance_id())
		
		var duration = custom_params.get("duration", effect_data.duration)
		self.time_left = duration
		var current_density = custom_params.get("density", effect_data.density)
	
		self.tick_timer = 0.0 
		if duration > 0.0 and current_density > 0.0:
			var final_params = {
				"intensity": custom_params.get("intensity", effect_data.intensity),
				"density": current_density,
				"duration": duration
			}
			effect_data.on_tick(target_char, final_params)

var active_effects: Dictionary = {}

var p_armor_add: float = 0.0
var p_armor_mult: float = 1.0

var speed_add: float = 0.0
var speed_mult: float = 1.0

var jump_add: float = 0.0
var jump_mult: float = 1.0

var tool_speed_add: float = 0.0
var tool_speed_mult: float = 1.0
var tool_cooldown: float = 1.0
var tool_cooldown_add: float = 0.0
var tool_cooldown_mult: float = 1.0
var can_use_tool: bool:
	get: return tool_cooldown <= 0.0

func _ready():
	var parent = get_parent()
	if parent is BaseCharacter:
		character = parent

func _process(delta: float) -> void:
	if tool_cooldown > 0.0:
		tool_cooldown -= delta
		if tool_cooldown < 0.0:
			tool_cooldown = 0.0
	var needs_update := false
	var effect_ids = active_effects.keys()
	
	for eff_id in effect_ids:
		var active_eff = active_effects[eff_id] as ActiveEffect
		var effect_data = active_eff.data
		
		if effect_data.duration > 0.0:
			active_eff.tick_timer += delta
			var current_density = effect_data.density 
			
			if active_eff.tick_timer >= current_density:
				active_eff.tick_timer -= current_density
				effect_data.on_tick(character)
		
		if effect_data.duration > 0.0 and active_eff.time_left > 0.0:
			active_eff.time_left -= delta
			
			if active_eff.time_left <= 0:
				remove_effect_by_id(eff_id)
				needs_update = true
				
	if needs_update:
		stats_updated.emit()

func reset_tool_cooldown(data: InvItemData):
	for effect in data.item_effects:
		if effect and effect.effect_id == "Cooldown":
			tool_cooldown = get_final_tool_speed(effect.intensity)
			break

func add_effect(new_effect_data: StatusEffect, custom_params: Dictionary = {}) -> String:
	var effect_id = new_effect_data.effect_id 
	var is_timed_effect = new_effect_data.duration > 0.0 or custom_params.has("duration")
	
	var final_params = {
		"intensity": custom_params.get("intensity", new_effect_data.intensity),
		"density": custom_params.get("density", new_effect_data.density),
		"duration": custom_params.get("duration", new_effect_data.duration)
	}
	
	if is_timed_effect:
		var existing_key = ""
		for key in active_effects.keys():
			if key.begins_with(effect_id + "_"):
				existing_key = key
				break
				
		if existing_key != "":
			var active_eff = active_effects[existing_key] as ActiveEffect
			active_eff.time_left = final_params["duration"]
			active_eff.tick_timer = 0.0
			return existing_key
		else:
			var runtime_effect = ActiveEffect.new(new_effect_data, custom_params, character)
			active_effects[runtime_effect.instance_id] = runtime_effect
			
			new_effect_data.apply(character, final_params, self)
			stats_updated.emit()
			return runtime_effect.instance_id
			
	else:
		var runtime_effect = ActiveEffect.new(new_effect_data, custom_params, character)
		active_effects[runtime_effect.instance_id] = runtime_effect
		
		new_effect_data.apply(character, final_params, self)
		stats_updated.emit()
		return runtime_effect.instance_id

func remove_effect_by_id(target_instance_id: String) -> void:
	if active_effects.has(target_instance_id):
		var active_eff = active_effects[target_instance_id] as ActiveEffect
		var effect_obj = active_eff.data
		
		var final_params = {
			"intensity": effect_obj.intensity, 
			"density": effect_obj.density, 
			"duration": effect_obj.duration
		}
		
		effect_obj.on_expire(character, final_params, self)
		
		active_effects.erase(target_instance_id)
		stats_updated.emit()

func get_final_armor() -> float:
	if character == null: return p_armor_add
	return (character.base_p_armor + p_armor_add) * p_armor_mult

func get_final_speed() -> float:
	if character == null: return speed_add
	return (character.SPEED + speed_add) * speed_mult

func get_final_jump() -> float:
	if character == null: return jump_add
	return (character.JUMP_VELOCITY + jump_add) * jump_mult

func get_final_tool_speed(tool_speed) -> float:
	return (tool_speed + tool_speed_add) * tool_speed_mult
	
func get_damage_package(weapon: InvItemData) -> DamageData:
	var combat_packet = DamageData.new(character, character.global_position if character else Vector2.ZERO)
	
	if weapon == null or weapon.item_effects.is_empty():
		return combat_packet
	for effect in weapon.item_effects:
		if effect == null: 
			continue
		
		if effect.effect_id == "PAttack":
			combat_packet.add_damage(effect.intensity, "Physical")
		elif effect.effect_id == "MAttack":
			combat_packet.add_damage(effect.intensity, "Magical")

		elif effect.effect_id == "Slowdown" or effect.effect_id == "Poison" or effect.effect_id == "Stun":
			combat_packet.add_effect(effect)
			
	return combat_packet
