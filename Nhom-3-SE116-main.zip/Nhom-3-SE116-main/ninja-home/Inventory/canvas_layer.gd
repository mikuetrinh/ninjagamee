extends CanvasLayer

@onready var main_inv = $InvUI
@onready var left_inv = $HBoxContainer/InvUILeft
@onready var right_panel = $HBoxContainer/AnyUIRight

func _ready():
	GameEvents.InteractMenu.connect(_on_interact_menu_requested)
	GameEvents.CloseAllMenu.connect(close_all_menus)
	visible = false
	
func _process(delta):
	if Input.is_action_just_pressed("inventory"):
		if not main_inv.is_open and not get_tree().paused:
			visible = true
			main_inv.open()
		else:
			close_all_menus()
			print("close inv")

func _on_interact_menu_requested(menu_scene: PackedScene):
	get_tree().paused = true
	visible = true
	
	left_inv.open() 
	
	for child in right_panel.get_children():
		child.queue_free()
	print(menu_scene)
	var new_sub_menu = menu_scene.instantiate()
	right_panel.add_child(new_sub_menu)
	
	if new_sub_menu.has_method("open_menu"):
		new_sub_menu.open_menu()

func close_all_menus():
	if main_inv and not main_inv.is_queued_for_deletion():
		main_inv.close()
	
	if left_inv and not left_inv.is_queued_for_deletion():
		left_inv.close()
	
	for child in right_panel.get_children():
		child.queue_free()
		
	visible = false
	get_tree().paused = false
