extends Control

var is_open = false
signal item_selected

@export var slot_ui_scene: PackedScene = preload("res://Inventory/inv_ui_slot.tscn")
@onready var generic_slots: Array = $InvBackground/GridContainer.get_children()

@onready var helmet_slot = $InvBackground/Armor/Helmet
@onready var chestplate_slot = $InvBackground/Armor/Chestplate
@onready var boots_slot = $InvBackground/Armor/Boots

var slots: Array = []
var selected_idx := 0
@onready var stats : Label = $InvBackground/InvStatDetails

func _ready():
	close()
	GameEvents.InventoryChange.connect(update_slots)
	
	slots.append_array(generic_slots)
	slots.append(helmet_slot)     
	slots.append(chestplate_slot)
	slots.append(boots_slot)
	
	for i in range(slots.size()):
		slots[i].slot_pos = i
		if not slots[i].slot_clicked.is_connected(sel_slot):
			slots[i].slot_clicked.connect(sel_slot)
			
	update_slots()

func update_stats(speed: float, cooldown: float, p_armor: float):
	stats.text = str(speed) + "\n" + str(cooldown * 100) + "%" + "\n" + str(p_armor)
	

func sel_slot(index: int, item: InvSlot):
	if selected_idx < slots.size():
		slots[selected_idx].off_selected()
		
	selected_idx = index
	
	if selected_idx < slots.size():
		slots[selected_idx].on_selected()
		
	InventoryManager.set_selected_item(item)
	item_selected.emit(get_sel_item())
	
func _process(_delta):
	if Input.is_action_just_pressed("interact"):
		if not is_open: open()
		else: close()

func get_sel_item() -> InvSlot:
	var inv = InventoryManager.inv
	if not inv: return null
	
	if selected_idx < 0 or selected_idx >= slots.size(): 
		return null
	return slots[selected_idx].slot_item
	
func update_slots():
	var inv = InventoryManager.inv
	if not inv: return
	
	var generic_size = generic_slots.size()
	
	for i in range(slots.size()):
		if i < generic_size:
			if i < inv.items.size():
				slots[i].visible = true 
				slots[i].slot_item = inv.items[i]
				slots[i].update_item(inv.items[i])
			else:
				slots[i].visible = false
		else:
			var armor_idx = i - generic_size
			
			slots[i].visible = true
			
			if armor_idx < inv.armor.size():
				if inv.armor[armor_idx] == null:
					inv.armor[armor_idx] = InvSlot.new()
					
				slots[i].slot_item = inv.armor[armor_idx]
				slots[i].update_item(inv.armor[armor_idx])
			else:
				slots[i].slot_item = null
				slots[i].update_item(null)

func close():
	visible = false
	is_open = false
	get_tree().paused = false 
	print("Game Unpaused")

func open():
	visible = true
	is_open = true
	update_slots()
	get_tree().paused = true 
	print("Game Paused")
