extends Node

@onready var sword_hitbox = $Blade
@onready var animation_player = $"../AnimationPlayer"

var current_weapon: InvItemData

func start_melee_attack(weapon_data: InvItemData):
	current_weapon = weapon_data
	sword_hitbox.weapon = weapon_data 
	
	animation_player.play("blade_events")
