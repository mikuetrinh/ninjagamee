extends BaseCharacter

@onready var hp_display: Label = $HP_Disp/Label
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var wander_timer: Timer = $WanderTimer
@onready var hurt_box: Area2D = $HurtBox

@export var detect_range: float = 200.0
@export var attack_range: float = 25.0
@export var attack_damage: int = 10
@export var attack_rate: float = 1.0
@export var wander_speed: float = 40.0
@export var chase_speed: float = 70.0

var player: CharacterBody2D
var targets_in_range := []

var move_direction: Vector2 = Vector2.ZERO
var is_walking: bool = false
var is_chasing: bool = false
var attack_timer: float = 0.0

var is_attacking: bool = false 

func _ready():
	super()
	
	if animated_sprite:
		animated_sprite.flip_h = false
		if not animated_sprite.animation_finished.is_connected(_on_animation_finished):
			animated_sprite.animation_finished.connect(_on_animation_finished)
	
	if hurt_box:
		if not hurt_box.area_entered.is_connected(_on_hurtbox_area_entered):
			hurt_box.area_entered.connect(_on_hurtbox_area_entered)
		if not hurt_box.area_exited.is_connected(_on_hurtbox_area_exited):
			hurt_box.area_exited.connect(_on_hurtbox_area_exited)
	
	if wander_timer:
		wander_timer.timeout.connect(_on_wander_timer_timeout)
	
	hp_display.update_hp(current_health, max_health)
	health_changed.connect(hp_display.update_hp)
	
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
		
	for child in get_children():
		if child is Area2D:
			child.scale = Vector2(1.2, 1.2)
			
	_select_new_state()

func _physics_process(delta: float) -> void:
	if dmg_timer > 0:
		dmg_timer -= delta

	if not is_on_floor():
		velocity += get_gravity() * delta
	else:
		velocity.y = 0

	var can_see_player: bool = false
	
	if player and is_instance_valid(player):
		var distance = global_position.distance_to(player.global_position)
		if distance <= detect_range:
			can_see_player = true

	if can_see_player:
		if not is_chasing:
			is_chasing = true
			if wander_timer:
				wander_timer.stop()
		
		var direction_x = sign(player.global_position.x - global_position.x)
		
		velocity.x = direction_x * chase_speed
		
	else:
		if is_chasing:
			is_chasing = false
			_select_new_state()
			
		if is_walking:
			velocity.x = move_direction.x * wander_speed
		else:
			velocity.x = move_toward(velocity.x, 0, wander_speed)

	move_and_slide()
	
	_update_animation()
	_handle_continuous_attack(delta)

func _on_hurtbox_area_entered(area: Area2D) -> void:
	if area.has_method("handle_hit") and not targets_in_range.has(area):
		targets_in_range.append(area)
		if attack_timer <= 0:
			_deal_damage_to_targets()

func _on_hurtbox_area_exited(area: Area2D) -> void:
	if targets_in_range.has(area):
		targets_in_range.erase(area)

func _handle_continuous_attack(delta: float) -> void:
	if attack_timer > 0:
		attack_timer -= delta
		
	if attack_timer <= 0 and targets_in_range.size() > 0:
		_deal_damage_to_targets()

func _deal_damage_to_targets() -> void:
	targets_in_range = targets_in_range.filter(func(a): return is_instance_valid(a))
	if targets_in_range.size() == 0:
		return
		
	is_attacking = true
		
	for area in targets_in_range:
		var combat_packet = DamageData.new(self, global_position)
		combat_packet.add_damage(attack_damage, "Physical")
		area.handle_hit(combat_packet)
		
	attack_timer = attack_rate

func _select_new_state() -> void:
	is_walking = [true, false].pick_random()
	if is_walking:
		move_direction = Vector2([ -1, 1 ].pick_random(), 0)
	
	if wander_timer:
		wander_timer.wait_time = randf_range(1.0, 2.0)
		wander_timer.start()

func _on_wander_timer_timeout() -> void:
	_select_new_state()

func _on_animation_finished() -> void:
	if animated_sprite.animation == "Attack":
		is_attacking = false

func _update_animation() -> void:
	if is_chasing and player and is_instance_valid(player):
		var dir_to_player = sign(player.global_position.x - global_position.x)
		if dir_to_player > 0:
			animated_sprite.scale.x = 1
		elif dir_to_player < 0:
			animated_sprite.scale.x = -1
	else:
		if velocity.x > 0:
			animated_sprite.scale.x = 1
		elif velocity.x < 0:
			animated_sprite.scale.x = -1

	if is_attacking:
		animated_sprite.play("Attack")
	elif abs(velocity.x) > 0 or is_chasing:
		animated_sprite.play("Walk")
	else:
		animated_sprite.play("Idle")
