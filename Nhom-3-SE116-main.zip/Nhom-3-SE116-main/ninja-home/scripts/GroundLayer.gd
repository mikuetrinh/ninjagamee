extends TileMapLayer
@export var item_pickup_scene: PackedScene
@export var player: CharacterBody2D

func _ready() -> void:
	pass

func use_scythe(player_global_pos: Vector2, facing_dir: Vector2, _radius: int = 2):
	print("using scythe with hardcoded mask")
	var player_cell = local_to_map(to_local(player_global_pos))
	
	var direction = "DOWN"
	if abs(facing_dir.x) > abs(facing_dir.y):
		direction = "RIGHT" if facing_dir.x > 0 else "LEFT"
	else:
		direction = "DOWN" if facing_dir.y > 0 else "UP"
		
	var offsets: Array[Vector2i] = []
	
	match direction:
		"UP":
			# . X X X .
			# X X X X X
			# X X P X X
			# . . . . .
			# . . . . .
			offsets = [
				Vector2i(-1, -2), Vector2i(0, -2), Vector2i(1, -2),
				Vector2i(-2, -1), Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1), Vector2i(2, -1),
				Vector2i(-2, 0),  Vector2i(-1, 0),  Vector2i(0, 0),  Vector2i(1, 0),  Vector2i(2, 0)
			]
		"DOWN":
			# . . . . .
			# . . . . .
			# X X P X X
			# X X X X X
			# . X X X .
			offsets = [
				Vector2i(-2, 0),  Vector2i(-1, 0),  Vector2i(0, 0),  Vector2i(1, 0),  Vector2i(2, 0),
				Vector2i(-2, 1),  Vector2i(-1, 1),  Vector2i(0, 1),  Vector2i(1, 1),  Vector2i(2, 1),
				Vector2i(-1, 2),  Vector2i(0, 2),   Vector2i(1, 2)
			]
		"RIGHT":
			# . . X X .
			# . . X X X
			# . . P X X
			# . . X X X
			# . . X X .
			offsets = [
				Vector2i(0, -2), Vector2i(1, -2),
				Vector2i(0, -1), Vector2i(1, -1), Vector2i(2, -1),
				Vector2i(0, 0),  Vector2i(1, 0),  Vector2i(2, 0),
				Vector2i(0, 1),  Vector2i(1, 1),  Vector2i(2, 1),
				Vector2i(0, 2),  Vector2i(1, 2)
			]
		"LEFT":
			# . X X . .
			# X X X . .
			# X X P . .
			# X X X . .
			# . X X . .
			offsets = [
				Vector2i(-1, -2), Vector2i(0, -2),
				Vector2i(-2, -1), Vector2i(-1, -1), Vector2i(0, -1),
				Vector2i(-2, 0),  Vector2i(-1, 0),  Vector2i(0, 0),
				Vector2i(-2, 1),  Vector2i(-1, 1),  Vector2i(0, 1),
				Vector2i(-1, 2),  Vector2i(0, 2)
			]

	for offset in offsets:
		var target_cell = player_cell + offset
		var tile = get_cell_tile_data(target_cell)
		
		if tile and tile.get_custom_data("tile_type") == "Grass":
			erase_tile(target_cell)

	
#func update_auto_tile(cell_pos: Vector2i):
	#var cell_id := get_cell_source_id(cell_pos)
	#if cell_id == -1: return
	#var mask := 0
	#if get_cell_source_id(cell_pos + Vector2i.RIGHT) == cell_id: mask += 1
	#if get_cell_source_id(cell_pos + Vector2i.LEFT) == cell_id: mask += 2
	#if get_cell_source_id(cell_pos + Vector2i.DOWN) == cell_id: mask += 4
	#if get_cell_source_id(cell_pos + Vector2i.UP) == cell_id: mask += 8
	
	#set_cell(cell_pos, cell_id, Vector2i(mask, 0))
	
func place_tile(cell_pos: Vector2i, item: InvSlot):
	if get_cell_tile_data(cell_pos) != null: return
	if item == null:
		return
	if item.data == null:
		return
	if item.amount <= 0:
		return
	if item.data.autotile:
		set_cell(cell_pos, item.data.source_id, Vector2i.ZERO)
		#update_auto_tile(cell_pos)
		#update_auto_tile(cell_pos + Vector2i.RIGHT)
		#update_auto_tile(cell_pos + Vector2i.LEFT)
		#update_auto_tile(cell_pos + Vector2i.UP)
		#update_auto_tile(cell_pos + Vector2i.DOWN)
	else:
		set_cell(cell_pos, item.data.source_id, item.data.coords)
	item.amount -= 1
	if item.amount < 1:
		print("out of item")
		GameEvents.EmptySlot.emit(item.location)
	GameEvents.InventoryChange.emit()

func erase_tile(cell_pos: Vector2i):
	var tile = get_cell_tile_data(cell_pos)
	if tile == null: 
		return
		
	if tile.get_custom_data("has_drop"):
		var item_drop_id = tile.get_custom_data("item_drop") 
		var item_to_drop = DropToItem.get_item(item_drop_id)
		
		if item_to_drop:
			var drop_global_pos = to_global(map_to_local(cell_pos))
			DropToItem.spawn_drop(drop_global_pos, item_to_drop)
	erase_cell(cell_pos)
	
	#update_auto_tile(cell_pos + Vector2i.RIGHT)
	#update_auto_tile(cell_pos + Vector2i.LEFT)
	#update_auto_tile(cell_pos + Vector2i.UP)
	#update_auto_tile(cell_pos + Vector2i.DOWN)

func _process(delta: float):
	pass
		
		
func _unhandled_input(event):
	var mouse_pos
	if event.is_action_pressed("perform"):
		var sel_item: InvSlot = InventoryManager.get_selected_item()
		if sel_item == null or sel_item.data == null: return
		if (sel_item.data.placable):
			mouse_pos = get_global_mouse_position()
			var cell_pos = local_to_map(to_local(mouse_pos))
			place_tile(cell_pos, sel_item)
		elif (sel_item.data.type == "Scythe"):
			print("Detected scythe")
			mouse_pos = get_global_mouse_position()
			var facing_dir = (mouse_pos - player.global_position).normalized()
			use_scythe(player.global_position, facing_dir, 2)
func process_tile(tile_pos):
	var tile_data = get_cell_tile_data(tile_pos)
	if tile_data == null:
		return
	
		
