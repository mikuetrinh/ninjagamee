extends Label

func update_hp(cur_hp: float, max_hp: float):
	print("updated hp", cur_hp)
	text = str(cur_hp) + "/" + str(max_hp)
