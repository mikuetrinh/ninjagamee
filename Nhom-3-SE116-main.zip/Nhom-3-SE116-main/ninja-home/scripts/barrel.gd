extends Area2D

@export var damage: float = 0.0
@onready var animated_sprite: AnimatedSprite2D = $"../AnimatedSprite2D"

func _ready() -> void:
	area_entered.connect(_on_area_entered)
	
	if animated_sprite != null:
		animated_sprite.play("Idle")
		if not animated_sprite.animation_finished.is_connected(_on_animation_finished):
			animated_sprite.animation_finished.connect(_on_animation_finished)
			
	set_physics_process(false)

func _on_area_entered(area: Area2D) -> void:
	if area.has_method("handle_hit"):
		
		if animated_sprite != null:
			animated_sprite.play("Boom")
			print("boom")
			
		var combat_packet = DamageData.new(self, global_position)
		combat_packet.add_damage(damage, "Physical")
		area.handle_hit(combat_packet)

func _on_animation_finished() -> void:
	if animated_sprite.animation == "Boom":
		get_parent().queue_free()
