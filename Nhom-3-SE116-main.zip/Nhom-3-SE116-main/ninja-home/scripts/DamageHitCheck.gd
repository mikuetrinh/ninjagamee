class_name HitCheck
extends Area2D
@onready var character: CharacterBody2D = $".."

func handle_hit(combat_packet: DamageData):
	if combat_packet == null: return
	if character.max_health == 0: return
	combat_packet.victim = get_parent()
	
	character.take_damage(combat_packet)
	
