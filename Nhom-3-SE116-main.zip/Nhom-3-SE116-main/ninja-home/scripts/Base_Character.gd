class_name BaseCharacter
extends CharacterBody2D

@export var SPEED: float = 100.0
@export var JUMP_VELOCITY: float = -320.0
@export var max_health: float = 100.0
@export var base_p_armor: float = 0.0
@export var base_tool_speed: float = 1.0

@export var inv: InvData
var current_health: float
var dmg_cooldown := 0.5
var dmg_timer := 0.0

@onready var world: TileMapLayer = $"../World"
@onready var state_machine = $StateMachine
@onready var stats_manager: StatsManager = $StatsManager
var equipped_armor_effect_ids: Array[String] = []

signal died(data: DamageData)
signal health_changed(current_health: float, max_health: float)
signal stats_changed(speed: float, tool_speed: float, p_armor: float)

var final_speed: float:
	get: return stats_manager.get_final_speed()

var final_jump: float:
	get: return stats_manager.get_final_jump()

var final_p_armor: float:
	get: return stats_manager.get_final_armor()

var final_tool_speed: float:
	get: return stats_manager.get_final_tool_speed(base_tool_speed)


func _ready():
	current_health = max_health 
	died.connect(on_death)
	
	GameEvents.InventoryChange.connect(update_inventory_stats)
	await stats_manager.stats_updated.connect(on_stats_recalculated)

func update_inventory_stats():
	for id in equipped_armor_effect_ids:
		stats_manager.remove_effect_by_id(id)
	equipped_armor_effect_ids.clear()
	
	if not inv or inv.armor.size() == 0:
		on_stats_recalculated()
		return
		
	for i in range(min(3, inv.armor.size())):
		var slot = inv.armor[i]
		if slot and slot.data and slot.data.is_armor:
			for effect in slot.data.item_effects:
				if effect:
					var id = stats_manager.add_effect(effect)
					
					equipped_armor_effect_ids.append(id)
	on_stats_recalculated()

func on_stats_recalculated():
	stats_changed.emit(final_speed, final_tool_speed, final_p_armor)

func apply_status_effect(effect_source: Variant, custom_params: Dictionary = {}):
	EffectManager.apply_effect(self, effect_source, custom_params)

func take_damage(data: DamageData) -> void:
	if current_health <= 0.0 or dmg_timer > 0.0:
		return
	var final_damage: float = 0.0
	
	for source in data.damage_sources:
		var calc_dmg: float = 0.0
		
		match source.type:
			"Physical":
				calc_dmg = source.damage * (100.0 - final_p_armor) / 100.0
			"Magical":
				var m_armor = get("final_m_armor") if "final_m_armor" in self else 0.0
				calc_dmg = source.damage * (100.0 - m_armor) / 100.0
			"True":
				calc_dmg = source.damage
				
		final_damage += maxf(0.0, calc_dmg)

	if final_damage > 0.0:
		current_health = maxf(0.0, current_health - final_damage)
		
		if stats_manager and not data.status_effects.is_empty():
			for effect in data.status_effects:
				if effect:
					stats_manager.add_effect(effect)
					print(name, " caught effect: ", effect.effect_id)
		
		GameEvents.damaged.emit(data)
		health_changed.emit(current_health, max_health)
		dmg_timer = dmg_cooldown
		if current_health <= 0.0:
			died.emit(data)
		
func on_death(data: DamageData):
	print(name, " is Dead")
	
	if is_in_group("Player"):
		GameEvents.player_died.emit(data)
	
	var pos: Vector2 = $DropPoint.global_position
	if inv:
		DropToItem.spawn_drop(pos, inv, 1)
		DropToItem.spawn_drop(pos, "Coin", inv.coins)
		
	queue_free()
