extends HitCheck

func handle_hit(combat_packet: DamageData):
	super(combat_packet)
	$"../StateMachine".get_hit(combat_packet)
