extends BaseStateMachine

@export var particle_scene: PackedScene
@export var eat_duration: float = 1.5

@export var particle_interval: float = 0.12
@export var particle_lifetime: float = 0.5

var eat_timer: float = 0.0
var particle_timer: float = 0.0

func enter():
	super()
	character.velocity.x = 0
	
	eat_timer = 0.0
	particle_timer = 0.0

func exit():
	super()

func physics_update(delta):
	if not Input.is_action_pressed("primary"):
		Transition.emit("Idle")
		return
		
	if not character.is_on_floor():
		Transition.emit("Fall")
		return
	
	eat_timer += delta
	
	particle_timer += delta
	
	if particle_timer >= particle_interval:
		particle_timer = 0.0
		spawn_eat_particles()
	
	if eat_timer >= eat_duration:
		print("Eat completed")
		on_eat_completed()

func spawn_eat_particles():
	if not particle_scene:
		return
	
	var particles = particle_scene.instantiate() as GPUParticles2D
	
	character.add_child(particles)
	
	particles.emitting = true
	get_tree().create_timer(particle_lifetime).timeout.connect(func():
		if is_instance_valid(particles):
			particles.queue_free()
	)

func on_eat_completed():
	var slot = InventoryManager.get_selected_item()
	if slot.data.is_food:
		if slot.data.item_effects.size() > 0:
			character.apply_status_effect(slot.data.item_effects)
			print("Eaten buff")
	if slot and slot.data:
		slot.amount -= 1
		
		if slot.amount < 1:
			slot.data = null
			
		GameEvents.InventoryChange.emit()
	
	Transition.emit("Idle")
