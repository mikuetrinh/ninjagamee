extends HitCheck
@onready var tree: CustomTree = $"../Area2D"

func handle_hit(combat_packet: DamageData):
	tree._action()
	print("hit")
