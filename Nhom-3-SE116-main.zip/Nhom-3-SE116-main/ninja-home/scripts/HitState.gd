class_name HitState
extends BaseStateMachine

func enter():
	super()
	
	if ani_player and not ani_player.animation_finished.is_connected(_on_animation_finished):
		ani_player.animation_finished.connect(_on_animation_finished)
	
	if character.is_on_floor(): character.velocity.x = 0

func physics_update(delta):
	if not character.is_on_floor():
		character.velocity += character.get_gravity() * delta

func _on_animation_finished():
	if ani_player and ani_player.animation == "hit":
		if ani_player.animation_finished.is_connected(_on_animation_finished):
			ani_player.animation_finished.disconnect(_on_animation_finished)
		
		if character.is_on_floor():
			Transition.emit("Idle")
		else:
			Transition.emit("Fall")

func exit():
	super()
	if ani_player and ani_player.animation_finished.is_connected(_on_animation_finished):
		ani_player.animation_finished.disconnect(_on_animation_finished)
