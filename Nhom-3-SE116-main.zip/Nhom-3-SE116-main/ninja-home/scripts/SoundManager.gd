extends Node

var bgm_player: AudioStreamPlayer

func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	bgm_player = AudioStreamPlayer.new()
	add_child(bgm_player)
	
	bgm_player.bus = "Music" 

func play_bgm(music_stream: AudioStream):
	if bgm_player.stream == music_stream and bgm_player.playing:
		return
		
	bgm_player.stream = music_stream
	bgm_player.play()

func stop_bgm():
	bgm_player.stop()

func play_sfx(sfx_stream: AudioStream):
	if sfx_stream == null:
		return
		
	var sfx_player = AudioStreamPlayer.new()
	add_child(sfx_player)
	
	sfx_player.stream = sfx_stream
	sfx_player.bus = "SFX"
	
	sfx_player.process_mode = Node.PROCESS_MODE_ALWAYS
	
	sfx_player.play()
	
	sfx_player.finished.connect(func(): sfx_player.queue_free())
	
