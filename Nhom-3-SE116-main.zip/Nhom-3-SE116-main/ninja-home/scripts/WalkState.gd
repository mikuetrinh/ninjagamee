extends BaseStateMachine

func enter():
	super()

func physics_update(delta):
	if not character.is_on_floor():
		Transition.emit("Fall")
		return
	
	if Input.is_action_just_pressed("jump"):
		Transition.emit("Jump")
		return
		
	var direction := Input.get_axis("left", "right")
	if direction == 0:
		Transition.emit("Idle")
		return
		
	character.velocity.x = direction * character.stats_manager.get_final_speed()
