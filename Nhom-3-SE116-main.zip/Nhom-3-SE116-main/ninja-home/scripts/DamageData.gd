class_name DamageData
extends RefCounted

class DamageSource:
	var damage: float    
	var type: String 
	
	func _init(_damage: float, _type: String = "Physical"):
		self.damage = _damage
		self.type = _type

var attacker: Node = null
var hit_position: Vector2 = Vector2.ZERO
var victim: Node = null

var damage_sources: Array[DamageSource] = []
var status_effects: Array[StatusEffect] = []

func _init(atk: Node, pos: Vector2):
	self.attacker = atk
	self.hit_position = pos

func add_damage(dmg: float, type: String):
	damage_sources.append(DamageSource.new(dmg, type))

func add_effect(effect: StatusEffect):
	status_effects.append(effect)
