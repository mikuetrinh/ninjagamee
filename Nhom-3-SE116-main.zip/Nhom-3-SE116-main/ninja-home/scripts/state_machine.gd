class_name StateMachine
extends Node2D

@export var initial_state: States

var cur_state: States
var states := {}

var hit_anim_timer := 0.0
var ani_player: AnimatedSprite2D


func _ready():
	await get_parent().ready

	ani_player = get_parent().get_node_or_null("AnimatedSprite2D")

	for child in get_children():
		if child is States:
			states[child.name.to_lower()] = child
			child.character = get_parent()
			child.Transition.connect(on_child_transition)

	if initial_state:
		cur_state = initial_state
		cur_state.enter()

	GameEvents.damaged.connect(get_hit)


func _process(delta):
	if cur_state:
		cur_state.process(delta)

	if hit_anim_timer > 0.0:
		hit_anim_timer -= delta
		if ani_player and ani_player.sprite_frames.has_animation("Hit"):
			if ani_player.animation != "Hit":
				ani_player.play("Hit")


func _physics_process(delta):
	if cur_state:
		cur_state.physics_update(delta)

func on_child_transition(new_state_name: String):
	var new_state: States = states.get(new_state_name.to_lower())

	if new_state == null or new_state == cur_state:
		return

	cur_state.exit()
	cur_state = new_state
	
	if new_state.name.to_lower() == "blade":
		hit_anim_timer = 0.0
	
	cur_state.enter()


func get_hit(data: DamageData):
	if data.victim != get_parent():
		return

	if cur_state and cur_state.name.to_lower() == "blade":
		print("Đang chém (Blade), chặn hoạt ảnh Hit để tránh lỗi animation!")
		return

	hit_anim_timer = 0.5
	
	if ani_player and ani_player.sprite_frames.has_animation("Hit"):
		ani_player.play("Hit")
