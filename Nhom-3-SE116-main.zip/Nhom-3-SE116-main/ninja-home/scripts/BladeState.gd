extends BaseStateMachine

@onready var PSprite: AnimatedSprite2D = $"../../AnimatedSprite2D"
@onready var blade: Area2D = $"../../Attack/Blade"
@onready var blade_player = $"../../AnimationPlayer"

func enter():
	super()
	character.velocity = Vector2.ZERO
	blade_player.play("blade")

	if ani_player and not ani_player.animation_finished.is_connected(_on_animation_finished):
		ani_player.animation_finished.connect(_on_animation_finished)
		
	if PSprite.scale.x < 0:
		blade.rotation_degrees = 180.0
	else:
		blade.rotation_degrees = 0.0

func exit():
	super()
	if ani_player and ani_player.animation_finished.is_connected(_on_animation_finished):
		ani_player.animation_finished.disconnect(_on_animation_finished)

func physics_update(_delta):
	character.velocity = Vector2.ZERO
	
func _on_animation_finished():
	if character.is_on_floor():
		var direction := Input.get_axis("left", "right")
		if direction != 0:
			Transition.emit("Walk")
		else:
			Transition.emit("Idle")
	else:
		Transition.emit("Fall")
