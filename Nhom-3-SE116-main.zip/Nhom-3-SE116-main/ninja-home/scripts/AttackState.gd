extends BaseStateMachine

@onready var animated_sprite: AnimatedSprite2D = $"../../AnimatedSprite2D"

func enter():
	super()
	character.velocity.x = 0
	
	animated_sprite.play("Attack")
	
	if not animated_sprite.animation_finished.is_connected(_on_animation_finished):
		animated_sprite.animation_finished.connect(_on_animation_finished)

func exit():
	super()
	if animated_sprite.animation_finished.is_connected(_on_animation_finished):
		animated_sprite.animation_finished.disconnect(_on_animation_finished)

func physics_update(_delta):
	character.velocity.x = 0

func _on_animation_finished():
	Transition.emit("Idle")
