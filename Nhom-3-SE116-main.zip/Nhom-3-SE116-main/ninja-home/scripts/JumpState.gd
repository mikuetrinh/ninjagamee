extends BaseStateMachine

func enter():
	super()
	character.velocity.y = character.JUMP_VELOCITY

func physics_update(delta):
	if character.velocity.y > 0:
		Transition.emit("Fall")
		return
		
	if Input.is_action_just_pressed("jump"):
		Transition.emit("DoubleJump")
		return
		
	var direction := Input.get_axis("left", "right")
	if direction != 0:
		character.velocity.x = direction * character.final_speed
	else:
		character.velocity.x = move_toward(character.velocity.x, 0, character.final_speed)
	
	if character.is_on_floor():
		Transition.emit("Idle")
