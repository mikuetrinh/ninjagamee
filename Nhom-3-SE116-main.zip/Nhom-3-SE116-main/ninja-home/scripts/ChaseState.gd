extends BaseStateMachine

@onready var animated_sprite: AnimatedSprite2D = $"../../AnimatedSprite2D"

func enter():
	super()
	print("chase")
	if animated_sprite: animated_sprite.play("Walk")

func physics_update(_delta):
	if character.player == null:
		Transition.emit("Idle")
		return

	var distance = character.global_position.distance_to(character.player.global_position)
	
	if distance > character.detect_range:
		Transition.emit("Idle")
		
	elif distance <= character.attack_range:
		Transition.emit("Attack")
		
	else:
		var direction = sign(character.player.global_position.x - character.global_position.x)
		
		character.velocity.x = direction * character.stats_manager.get_final_speed()
				
		if direction > 0:
			animated_sprite.scale.x = 1
		elif direction < 0:
			animated_sprite.scale.x = -1
