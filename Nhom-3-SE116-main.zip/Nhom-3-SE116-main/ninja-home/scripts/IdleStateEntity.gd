extends BaseStateMachine

func enter():
	super()
	character.velocity.x = 0
	print("IdledDummy")

func physics_update(delta):
	if not character.is_on_floor():
		Transition.emit("Fall")
		return
	
	Transition.emit("Idle")
