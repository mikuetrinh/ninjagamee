extends Area2D

var weapon: InvItemData
var hit_targets := []
@onready var character: BaseCharacter = $"../.."
@onready var hitbox: CollisionShape2D = $HitBox
@onready var sfx := $AudioStreamPlayer

func _ready():
	monitoring = false
	hitbox.set_deferred("disabled", true)
	if not area_entered.is_connected(_on_area_entered):
		area_entered.connect(_on_area_entered)
	
func start_attack():
	hit_targets.clear()
	monitoring = true
	hitbox.set_deferred("disabled", false)
	sfx.play()

func end_attack():
	monitoring = false
	hit_targets.clear()
	hitbox.set_deferred("disabled", true)

func _on_area_entered(area: Area2D):
	if weapon:
		if area is HitCheck:
			if area in hit_targets:
				return
				
			hit_targets.append(area)
			if !hit_targets.is_empty():
				print("hit something")
				print(hit_targets[0])
			var combat_packet = character.stats_manager.get_damage_package(weapon)
			area.handle_hit(combat_packet)
