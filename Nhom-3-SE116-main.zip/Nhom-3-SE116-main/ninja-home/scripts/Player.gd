class_name Player
extends BaseCharacter

@onready var PSprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var hp_display: Label = $CanvasLayer/HP/health_num
@onready var coin_display: Label = $CanvasLayer/Coin/CoinCount
@onready var tool_timer: Timer = $GlobalToolTimer
@onready var inv_ui = $SubInvLayer/InvUI

var hold_time := 0.0
var ini_hold := 0.0
var hold_threshold := 0.5
var repeat_delay := 0.1

func _ready():
	super()
	
	InventoryManager.inv = inv
	inv.setup()
	add_to_group("Player")
	
	if SceneManager.tele_player:
		global_position = SceneManager.target_pos
			
		SceneManager.tele_player = false
		SceneManager.player_data.clear()
		
	hp_display.update_hp(current_health, max_health)
	health_changed.connect(hp_display.update_hp)
	inv_ui.update_stats(final_speed, final_tool_speed, final_p_armor)
	stats_changed.connect(inv_ui.update_stats)
	coin_display.update_coin()
	GameEvents.InventoryChange.connect(coin_display.update_coin)
		
func _process(delta):
	var item_selected: InvSlot = InventoryManager.get_selected_item()
	if Input.is_action_just_pressed("drop"):
		drop_item(item_selected)
	if Input.is_action_pressed("drop"):
		ini_hold += delta
		if ini_hold >= hold_threshold:
			hold_time += delta
			if hold_time > repeat_delay:
				drop_item(item_selected)
				hold_time = 0.0
	else:
		ini_hold = 0
		hold_time = 0
	
func on_primary_click(item_selected: InvSlot):
	pass
		
func drop_item(slot: InvSlot):
	var pos: Vector2 = $DropPoint.global_position
	DropToItem.spawn_drop(pos, slot.data, 1, 3.0)
	slot.amount -= 1
	if slot.amount < 1:
		slot.data = null
	GameEvents.InventoryChange.emit()
		

func _physics_process(delta: float) -> void:
	if dmg_timer > 0:
		dmg_timer -= delta

	if not is_on_floor():
		velocity += get_gravity() * delta

	var direction := Input.get_axis("left", "right")
	if direction > 0:
		PSprite.scale.x = 1
	elif direction < 0:
		PSprite.scale.x = -1

	move_and_slide()
