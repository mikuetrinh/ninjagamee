class_name BaseStateMachine
extends States

@export var ani_name: String
var ani_player: AnimatedSprite2D = null

var is_animation_locked: bool = false

func enter():
	if not ani_player:
		ani_player = character.get_node_or_null("AnimatedSprite2D")
	
	if ani_player and ani_name != "":
		var state_machine = get_parent()
		
		if state_machine and "is_animation_locked" in state_machine and state_machine.is_animation_locked:
			return
			
		if ani_player.animation != ani_name:
			ani_player.play(ani_name)
