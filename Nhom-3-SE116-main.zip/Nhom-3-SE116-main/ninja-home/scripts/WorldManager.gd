extends Node

var PassedStage2: bool = false

@export var spawn_pos: Vector2 = Vector2(100, 0)

var target_scene: String:
	get:
		if not PassedStage2:
			return "res://scenes/Start/Start.tscn"
		else:
			return "res://scenes/Gameplay/Homebase_scene.tscn"
