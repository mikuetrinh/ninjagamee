extends Node

signal InventoryChange
signal EmptySlot(idx: int)
signal damaged(data: DamageData)
signal ShowTooltip(data: InvSlot)
signal ShowEffectTooltip(effect_name: String, time_left_str: String, effect_bbcode: String)
signal HideTooltip
signal InteractMenu(menu_scene: PackedScene)
signal CloseAllMenu
signal player_died(data: DamageData)
