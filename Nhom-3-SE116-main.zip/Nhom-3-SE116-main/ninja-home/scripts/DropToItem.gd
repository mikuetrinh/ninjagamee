extends Node

var items := {}

const BOUNCE_THRESHOLD_X := 20.0
const BOUNCE_THRESHOLD_Y := 50.0
const BOUNCE_EFFICIENCY := 0.5

func _ready():
	register(preload("res://Inventory/Items/Apple.tres"))
	register(preload("res://Inventory/Items/Wood.tres"))
	register(preload("res://Inventory/Items/Meat.tres")) 
	register(preload("res://Inventory/Items/Leather.tres"))
	register(preload("res://Inventory/Items/Single_Coin.tres"))


func register(item: InvItemData):
	if item:
		items[item.item_name] = item


func get_item(id: String) -> InvItemData:
	return items.get(id)

func spawn_drop(global_pos: Vector2, item_source: Variant, amount: int = 1, timer: float = 0.5):
	var data: InvItemData = null
	if amount < 1:
		return
	if item_source is InvSlot:
		if item_source.data == null or item_source.amount <= 0:
			return
		spawn_drop(global_pos, item_source.data, item_source.amount, timer)
		return
	if item_source is Array:
		for stuff in item_source:
			spawn_drop(global_pos, stuff, amount, timer)
		return
		
	if item_source is InvData:
		for stuff in item_source.items:
			if stuff.data and stuff.amount > 0:
				spawn_drop(global_pos, stuff.data, stuff.amount, timer)
		return

	if item_source is String:
		if item_source == "Coin":
			data = get_item("Single Coin")
			print("detected coin")
		else:
			data = get_item(item_source)

	elif item_source is InvItemData:
		data = item_source
		
	for i in range(amount):
		if not data:
			push_warning("No item found to drop")
			return
			
		var drop_scene = preload("res://Inventory/item_drop.tscn")
		var drop_instance = drop_scene.instantiate()
		
		drop_instance.item_data = data
		drop_instance.global_position = global_pos
		print(data.item_name)
		if timer > 0.0:
			var pick_area = drop_instance.get_node_or_null("PickArea")
			if pick_area:
				pick_area.monitoring = false
				get_tree().create_timer(timer).timeout.connect(func():
					if is_instance_valid(pick_area):
						pick_area.monitoring = true
				)
		
		get_tree().current_scene.add_child(drop_instance)
		
		var rand_x = (randf_range(-75, 75) + randf_range(-75, 75)) / 2.0
		var rand_y = (randf_range(-200, -300) + randf_range(-200, -300)) / 2.0
		drop_instance.velocity = Vector2(rand_x, rand_y)
