extends HBoxContainer

@export var effect_icon_scene: PackedScene = preload("res://scenes/EffectHUDIcon.tscn")


func _ready() -> void:
	if not effect_icon_scene:
		effect_icon_scene = preload("res://scenes/EffectHUDIcon.tscn") # <-- Thay đổi đường dẫn cho đúng map của bạn


func _process(_delta: float) -> void:
	# 1. Tìm nhân vật Player
	var player = get_tree().get_first_node_in_group("Player")
	if not player or not player.has_node("StatsManager"):
		_clear_all_icons()
		return
		
	var stats_manager = player.get_node("StatsManager") as StatsManager
	
	var all_effects = stats_manager.active_effects.values()
	
	var timed_effects: Array = []
	for active_eff in all_effects:
		if active_eff and active_eff.data and active_eff.data.duration > 0.0 and active_eff.time_left > 0.0:
			timed_effects.append(active_eff)
			
	_synchronize_effect_icons(timed_effects)


func _synchronize_effect_icons(valid_timed_effects: Array):
	for child in get_children():
		if child is EffectIconUI:
			var is_still_valid := false
			for effect in valid_timed_effects:
				if child.active_effect_ref == effect:
					is_still_valid = true
					break
			
			if not is_still_valid:
				child.queue_free()

	for effect in valid_timed_effects:
		var already_has_ui := false
		for child in get_children():
			if child is EffectIconUI and child.active_effect_ref == effect:
				already_has_ui = true
				break
				
		if not already_has_ui:
			var new_icon = effect_icon_scene.instantiate() as EffectIconUI
			add_child(new_icon)
			new_icon.setup(effect)


func _clear_all_icons():
	for child in get_children():
		child.queue_free()
