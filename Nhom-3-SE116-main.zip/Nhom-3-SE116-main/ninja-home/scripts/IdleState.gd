extends BaseStateMachine
@onready var attack: Node = $"../../Attack"

func enter():
	super()
	character.velocity.x = 0

func physics_update(delta):
	if not character.is_on_floor():
		Transition.emit("Fall")
		return
	
	if Input.is_action_just_pressed("jump"):
		Transition.emit("Jump")
		return
		
	var direction := Input.get_axis("left", "right")
	if direction != 0:
		Transition.emit("Walk")
		return
		
func _unhandled_input(event):
	if Input.is_action_just_pressed("primary"):
		print("primary pressed")
		var slot: InvSlot = InventoryManager.get_selected_item()
		if slot and slot.data:
			var data = slot.data
			
			if data.is_food:
				Transition.emit("Eat")
				return
			
			if data.is_weapon and data.type == "Blade":
				if not character.stats_manager.can_use_tool:
					print("On cooldown")
					return
				character.stats_manager.reset_tool_cooldown(data)
				Transition.emit("Blade")
				attack.start_melee_attack(data)
				return
				
