extends BaseCharacter

@onready var hp_display: Label = $HP_Disp/Label
@export var wander_speed: float = 40.0
@onready var wander_timer: Timer = $WanderTimer
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D 

const MEAT_RESOURCE = preload("res://Inventory/Items/Meat.tres")
const LEATHER_RESOURCE = preload("res://Inventory/Items/Leather.tres")

var gravity: int = ProjectSettings.get_setting("physics/2d/default_gravity")
var move_direction: Vector2 = Vector2.ZERO
var is_walking: bool = false
var is_taking_damage: bool = false 

func _ready() -> void:
	super()
	
	hp_display.update_hp(current_health, max_health)
	health_changed.connect(hp_display.update_hp)
	_select_new_state()

func _physics_process(delta: float) -> void:
	if dmg_timer > 0:
		dmg_timer -= delta

	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		velocity.y = 0

	if not is_taking_damage:
		if is_walking:
			velocity.x = move_direction.x * wander_speed
		else:
			velocity.x = move_toward(velocity.x, 0, wander_speed)
	else:
		velocity.x = move_toward(velocity.x, 0, wander_speed * 2)
	
	move_and_slide()
	_update_animation() 

func take_damage(data: DamageData) -> void:
	super(data)
	if current_health > 0:
		is_taking_damage = true
		animated_sprite.play("hit")
		await get_tree().create_timer(0.2).timeout
		is_taking_damage = false

func _update_animation() -> void:
	if is_taking_damage:
		return
	if abs(velocity.x) > 0:
		animated_sprite.play("walk")
		if velocity.x != 0:
			animated_sprite.flip_h = velocity.x < 0
	else:
		animated_sprite.play("idle")

func _select_new_state() -> void:
	is_walking = [true, false].pick_random()
	if is_walking:
		move_direction = Vector2([ -1, 1 ].pick_random(), 0)
	
	wander_timer.wait_time = randf_range(1.0, 2.0)
	wander_timer.start()

func _on_wander_timer_timeout() -> void:
	_select_new_state()

func on_death(killer = null):
	print("Con bò đã chết")
	
	DropToItem.register(MEAT_RESOURCE)
	DropToItem.register(LEATHER_RESOURCE)
	
	DropToItem.spawn_drop(global_position, MEAT_RESOURCE, 1, 0.5)
	DropToItem.spawn_drop(global_position, LEATHER_RESOURCE, 1, 0.5)
		
	queue_free()
