extends Label

func update_coin():
	text = str(InventoryManager.inv.coins)
