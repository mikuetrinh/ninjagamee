extends TextureRect
class_name EffectIconUI

var active_effect_ref: Variant
var is_hovered: bool = false


func setup(active_effect: Variant):
	active_effect_ref = active_effect
	
	if active_effect.data and active_effect.data.icon:
		texture = active_effect.data.icon
		
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)


func _process(_delta: float) -> void:
	if active_effect_ref == null:
		return
		
	if is_hovered:
		_trigger_custom_tooltip()


func _trigger_custom_tooltip():
	if active_effect_ref == null or active_effect_ref.data == null:
		return
		
	var effect_name = active_effect_ref.data.effect_id
	var time_left_str = "Duration: %.1fs" % active_effect_ref.time_left if active_effect_ref.time_left > 0 else "Permanent"
	var effect_bbcode = active_effect_ref.data.get_effect_string({"duration": active_effect_ref.time_left})
	
	GameEvents.ShowEffectTooltip.emit(effect_name, time_left_str, effect_bbcode)


func _on_mouse_entered():
	is_hovered = true
	_trigger_custom_tooltip()


func _on_mouse_exited():
	is_hovered = false
	GameEvents.HideTooltip.emit()
