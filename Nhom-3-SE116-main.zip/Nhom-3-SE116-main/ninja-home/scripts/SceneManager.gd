extends Node

var player_data: Dictionary = {}
var target_pos: Vector2
var tele_player: bool = false


func _ready():
	get_tree().node_added.connect(_on_node_added)


func change_scene(target_scene: String, spawn_pos: Vector2, player: BaseCharacter):
	if player:
		var timed_effects_data: Array[Dictionary] = []
		if player.stats_manager:
			for active_eff in player.stats_manager.active_effects.values():
				if active_eff.data and active_eff.data.duration > 0.0 and active_eff.time_left > 0.0:
					timed_effects_data.append({
						"effect_resource": active_eff.data,
						"time_left": active_eff.time_left,
						"tick_timer": active_eff.tick_timer
					})

		player_data = {
			"current_health": player.current_health,
			"inv": player.inv,
			"timed_effects": timed_effects_data
		}
	else:
		player_data = {
			"current_health": 100.0,
			"inv": InventoryManager.inv if "inv" in InventoryManager else null,
			"timed_effects": []
		}
	
	target_pos = spawn_pos
	tele_player = true
	
	get_tree().change_scene_to_file(target_scene)


func _on_node_added(node: Node):
	if tele_player and node.is_in_group("Player") and node is BaseCharacter:
		print("added node")
		
		tele_player = false 
		
		var local_player_data = player_data.duplicate(true)
		player_data.clear()
		
		var new_player = node as BaseCharacter
		
		await get_tree().process_frame
		if not is_instance_valid(new_player): return
		
		new_player.global_position = target_pos
		print(2, local_player_data)
		
		if not local_player_data.is_empty():
			print("not empty")
			if local_player_data.has("inv") and local_player_data["inv"] != null:
				new_player.inv = local_player_data["inv"]
				new_player.update_inventory_stats()
			
			if local_player_data.has("current_health"):
				new_player.current_health = local_player_data["current_health"]
				print("Máu sau khi nạp: ", new_player.current_health)
				new_player.health_changed.emit(new_player.current_health, new_player.max_health)
				
			if local_player_data.has("timed_effects") and new_player.stats_manager:
				for eff_save in local_player_data["timed_effects"]:
					var eff_data = eff_save["effect_resource"] as StatusEffect
					var custom_params = {"duration": eff_save["time_left"]}
					var instance_id = new_player.stats_manager.add_effect(eff_data, custom_params)
					
					if new_player.stats_manager.active_effects.has(instance_id):
						var active_eff = new_player.stats_manager.active_effects[instance_id]
						active_eff.time_left = eff_save["time_left"]
						active_eff.tick_timer = eff_save["tick_timer"]
