extends Area2D
class_name CustomTree

const TREE_FILLED = preload("res://assets/items/TreeApple.png")
const TREE_EMPTY = preload("res://assets/items/TreeNoApple.png")

@onready var tree_apple: Sprite2D = $TreeApple
@onready var label: Label = $Label


var is_harvested: bool = false
var hold_timer: SceneTreeTimer = null
var rng = RandomNumberGenerator.new()
var timer = 0


@export var animation_timer = 0.3

func _process(delta):
	label.text = "Refilling."
	timer += delta
	for i in range(int(timer / animation_timer)):
		label.text += "."
	if (timer > animation_timer * 3): 
		label.text = "Refilling."
		timer = 0
	pass

func _action() -> void:
	if (!is_harvested):
		DropToItem.spawn_drop(global_position, "Apple", 1)
	
	if (rng.randi_range(1,2)) == 2:
		is_harvested = true
		tree_apple.texture = TREE_EMPTY
		label.show()
		get_tree().create_timer(10.0).timeout.connect(_refill)

func _refill() -> void:
	tree_apple.texture = TREE_FILLED
	is_harvested = false
	print("Tree Refilled")
	label.hide()
