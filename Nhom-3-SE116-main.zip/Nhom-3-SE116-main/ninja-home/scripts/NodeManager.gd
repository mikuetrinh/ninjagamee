extends Node

func get_ancestor_by_class(start_node: Node, target_class) -> Node:
	var current = start_node
	
	while current != null:
		if is_instance_of(current, target_class):
			return current 
		current = current.get_parent() 
		
	return null
