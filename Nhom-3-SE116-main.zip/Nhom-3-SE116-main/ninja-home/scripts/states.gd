class_name States
extends Node2D
var character: CharacterBody2D
signal Transition(state_name: String)

func enter():
	pass
	
func process(delta: float):
	pass

func exit():
	pass
	
func physics_update(delta):
	pass
