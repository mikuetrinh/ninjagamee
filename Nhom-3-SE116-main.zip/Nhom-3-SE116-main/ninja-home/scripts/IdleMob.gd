extends BaseStateMachine

@onready var animated_sprite: AnimatedSprite2D = $"../../AnimatedSprite2D"

func enter():
	super()
	character.velocity.x = 0
	if animated_sprite: animated_sprite.play("Idle") 

func physics_update(_delta):
	if character.player == null:
		return
		
	var distance = character.global_position.distance_to(character.player.global_position)
	
	if distance <= character.attack_range:
		Transition.emit("Attack")
	elif distance <= character.detect_range:
		Transition.emit("Chase")
